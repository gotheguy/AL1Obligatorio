package obligatorio;

public interface ICola {

    public void econlar(Object dato);

    public void desencolar();

    public boolean EstaVacia();

    public Object Frente();

    public void Vaciar();

}
